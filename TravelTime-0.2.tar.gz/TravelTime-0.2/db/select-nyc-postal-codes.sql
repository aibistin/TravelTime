SELECT postal_code FROM us_cities WHERE 
                  country_code='US'
                  and state_code='NY'
                  and county_name in ('Bronx', 'Kings', 'New York', 'Queens','Richmond ')
    ORDER BY us_cities.postal_code;
