    --
    -- Mover Database
    --
   DROP TABLE if EXISTS cities.us_cities;
    
    
   PRAGMA foreign_keys = ON;


--
--   Create a US Cities Table
--   Using data from geonames.org
--
--country code      : iso country code, 2 characters
--postal code       : varchar(20)
--place name        : varchar(180)
--admin name1       : 1. order subdivision (state) varchar(100)
--admin code1       : 1. order subdivision (state) varchar(20)
--admin name2       : 2. order subdivision (county/province) varchar(100)
--admin code2       : 2. order subdivision (county/province) varchar(20)
--admin name3       : 3. order subdivision (community) varchar(100)
--admin code3       : 3. order subdivision (community) varchar(20)
--latitude          : estimated latitude (wgs84)
--longitude         : estimated longitude (wgs84)
--accuracy          : accuracy of lat/lng from 1=estimated to 6=centroid
--
    CREATE TABLE IF NOT EXISTS  cities.us_cities (
            id          INTEGER PRIMARY KEY,
            country_code          TEXT, 
            postal_code           varchar(20), 
            place_name            varchar(180), 
            state_name           varchar(100), 
            state_code           varchar(20), 
            county_name          varchar(100), 
            county_code          varchar(20), 
            community_name       varchar(100), 
            community_code       varchar(20), 
            latitude              decimal(10, 5), 
            longitude             decimal(10, 5), 
            accuracy              INTEGER, 
            created      TIMESTAMP,
            updated      TIMESTAMP
            );

/*
script/mover_create.pl model DB DBIC::Schema mover::Schema \
        create=static components=TimeStamp dbi:SQLite:mover.db \
        on_connect_do="PRAGMA foreign_keys = ON"
*/


-- 
-- Create a view of New York City and 5 Boroughs Zip codes
-- 
   DROP VIEW if EXISTS cities.nyc_zips;

   CREATE VIEW IF NOT EXISTS  cities.nyc_zips (
         AS  SELECT postal_code FROM cities.us_cities WHERE 
                  country_code="US"
                  and state_code="NY"
                  and county_name in ('Bronx', 'Kings', 'New York', 'Queens','Richmond ')
    ORDER BY us_cities.postal_code;
    );
